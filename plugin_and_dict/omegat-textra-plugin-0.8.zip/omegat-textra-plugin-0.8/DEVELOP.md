# Developer note

## Development tools

ReST plugin is developed with Gradle build tool and IntelliJ IDEA. 
It depends on  Java8.

