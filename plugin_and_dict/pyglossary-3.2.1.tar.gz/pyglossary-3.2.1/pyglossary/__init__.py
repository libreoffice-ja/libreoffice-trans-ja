from .core import log, VERSION
from .glossary import Glossary

__version__ = VERSION
