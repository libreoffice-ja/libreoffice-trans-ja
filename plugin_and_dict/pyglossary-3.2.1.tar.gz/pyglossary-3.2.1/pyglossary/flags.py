ALWAYS = 'always'
DEFAULT_YES = 'default_yes'
DEFAULT_NO = 'default_no'
NEVER = 'never'
